import React from 'react';
import { MessageSquare, PhoneIncoming, Clock } from 'lucide-react';

export default function WhatsAppLogsPage() {
  const logs = [
    { id: 1, phone: '+91 98765 43210', message: 'Report: Pothole at MG Road', status: 'Converted', time: '10:24 AM' },
    { id: 2, phone: '+91 87654 32109', message: 'Hi, I want to track my report #CIV-402', status: 'Bot Reply', time: '11:15 AM' },
    { id: 3, phone: '+91 76543 21098', message: 'Streetlight not working in Baner', status: 'Critical', time: '11:45 AM' },
  ];

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold font-serif text-primary">WhatsApp Intake Logs</h1>
          <p className="text-muted-foreground mt-1">Live feed of citizen reports coming through the WhatsApp AI Gateway.</p>
        </div>
        <div className="flex gap-3">
          <div className="bg-secondary px-4 py-2 rounded-lg text-sm font-semibold">Gateway: Active</div>
          <div className="bg-[#f2f7f3] text-[#4a7c59] px-4 py-2 rounded-lg text-sm font-semibold">324 Today</div>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-secondary border-b border-border">
              <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Citizen Phone</th>
              <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Inbound Message</th>
              <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">AI Action</th>
              <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {logs.map((log) => (
              <tr key={log.id} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-secondary rounded-full text-primary"><PhoneIncoming size={14} /></div>
                    <span className="font-mono text-sm">{log.phone}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm font-medium italic">"{log.message}"</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-[4px] text-[10px] font-bold uppercase tracking-wider ${
                    log.status === 'Converted' ? 'bg-[#f2f7f3] text-[#4a7c59]' : 
                    (log.status === 'Critical' ? 'bg-[#fdf2f0] text-[#c24127]' : 'bg-secondary text-primary')
                  }`}>
                    {log.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1.5"><Clock size={12} /> {log.time}</div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
